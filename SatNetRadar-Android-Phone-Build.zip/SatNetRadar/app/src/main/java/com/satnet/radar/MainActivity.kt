package com.satnet.radar

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 17, 31)
    private val panel = Color.rgb(14, 31, 51)
    private val mint = Color.rgb(72, 227, 154)
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var speedText: TextView
    private lateinit var scoreText: TextView
    private lateinit var gauge: GaugeView
    private lateinit var wifiList: LinearLayout
    private lateinit var vpnConfig: EditText
    private lateinit var vpnStatus: TextView
    private lateinit var wifiManager: WifiManager
    private var backend: GoBackend? = null
    private var vpnUp = false
    private val tunnel = object : Tunnel {
        override fun getName() = "SatNet-WireGuard"
        override fun onStateChange(newState: Tunnel.State) { runOnUiThread { vpnUp = newState == Tunnel.State.UP; vpnStatus.text = if (vpnUp) "● تونل فعال است" else "○ تونل قطع است" } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        wifiManager = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        backend = GoBackend(this)
        buildHome()
        requestNeededPermissions()
    }

    private fun buildHome() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(18, 14, 18, 18) }
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val title = TextView(this).apply { text = "مدارنت  /  SATNET"; textSize = 25f; setTextColor(mint); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, 14, 0, 4) }
        body.addView(title)
        body.addView(label("پایشگر شبکه • رادار امواج • تونل امن", 13, 0xFF91A9C2.toInt(), true))
        body.addView(section("سرعت اینترنت"))
        gauge = GaugeView(this)
        body.addView(gauge, LinearLayout.LayoutParams(-1, 190))
        speedText = label("۰٫۰۰ Mbps", 29, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        scoreText = label("امتیاز کیفیت: -- / ۱۰۰", 16, mint, true).apply { gravity = Gravity.CENTER }
        body.addView(speedText); body.addView(scoreText)
        status = label("شبکه فعال: در حال بررسی…", 13, 0xFFB5C8DB.toInt(), false)
        body.addView(status)
        val wifiIp = edit("IP مودم (اختیاری؛ مانند 192.168.1.1)")
        body.addView(wifiIp)
        val row1 = horizontal()
        row1.addView(button("سنجش وای‌فای") { runSpeedTest("Wi‑Fi", wifiIp.text.toString()) }, weightParams())
        row1.addView(button("سنجش اینترنت همراه") { runSpeedTest("اینترنت همراه", "") }, weightParams())
        body.addView(row1)
        body.addView(section("رادار شبکه‌های اطراف"))
        body.addView(label("اسکن شبکه‌های قابل‌مشاهده در محدوده دریافت گوشی؛ فاصله ۵۰۰ متر تضمین‌شدنی نیست.", 12, 0xFF91A9C2.toInt(), false))
        body.addView(button("اسکن وای‌فای‌های اطراف") { scanWifi() })
        wifiList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(wifiList)
        val mapCard = card()
        mapCard.addView(label("نقشه و موقعیت", 17, mint, true))
        mapCard.addView(label("اندروید از اسکن وای‌فای، مختصات جغرافیایی مودم‌ها را نمی‌دهد؛ بنابراین نمایش نقطهٔ دقیق هر مودم روی نقشه ممکن نیست. این نسخه شبکه‌ها را در فهرست راداری نشان می‌دهد و محل مودم را حدس نمی‌زند.", 12, 0xFFB5C8DB.toInt(), false))
        body.addView(mapCard)
        body.addView(section("VPN امن WireGuard"))
        vpnStatus = label("○ تونل قطع است", 14, 0xFFFFC857.toInt(), true)
        body.addView(vpnStatus)
        body.addView(label("برای اتصال واقعی، فایل پیکربندی WireGuard (.conf) و سرور فعال لازم است. این برنامه سرور رایگان یا نامحدودِ آماده ارائه نمی‌کند.", 12, 0xFF91A9C2.toInt(), false))
        vpnConfig = edit("محتوای فایل WireGuard را اینجا وارد کن…", multiline = true)
        body.addView(vpnConfig, LinearLayout.LayoutParams(-1, 170))
        val vpnRow = horizontal()
        vpnRow.addView(button("اتصال VPN") { connectVpn() }, weightParams())
        vpnRow.addView(button("قطع VPN") { disconnectVpn() }, weightParams())
        body.addView(vpnRow)
        body.addView(label("طراحی فضایی با تم ماهواره‌ای و امواج فرکانسی • نسخه آزمایشی ۱٫۰", 11, 0xFF7189A3.toInt(), false).apply { gravity = Gravity.CENTER; setPadding(0, 20, 0, 10) })
        setContentView(root)
        refreshNetworkLabel()
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 41)
    }

    private fun refreshNetworkLabel() {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val name = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi‑Fi"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "اینترنت همراه"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "اترنت"
            else -> "نامشخص / بدون اتصال"
        }
        status.text = "شبکه فعال گوشی: $name"
    }

    private fun runSpeedTest(label: String, routerIp: String) {
        if (label == "Wi‑Fi" && !isWifiConnected()) { toast("برای سنجش وای‌فای، ابتدا به همان وای‌فای متصل شو."); return }
        if (label == "اینترنت همراه" && !isCellularConnected()) { toast("برای سنجش اینترنت همراه، وای‌فای را خاموش و دیتای سیم‌کارت را روشن کن."); return }
        if (routerIp.isNotBlank() && !routerIp.matches(Regex("^[0-9a-fA-F:.]+$"))) { toast("فرمت IP واردشده معتبر نیست."); return }
        speedText.text = "در حال سنجش…"; scoreText.text = "لطفاً چند لحظه صبر کن"; gauge.setSpeed(0.0)
        thread {
            try {
                val pingStart = System.currentTimeMillis()
                repeat(3) { fetchBytes("https://speed.cloudflare.com/__down?bytes=1000", 1000) }
                val ping = (System.currentTimeMillis() - pingStart) / 3.0
                val bytes = 8_000_000
                val start = System.nanoTime(); fetchBytes("https://speed.cloudflare.com/__down?bytes=$bytes", bytes); val seconds = (System.nanoTime() - start) / 1e9
                val mbps = bytes * 8.0 / seconds / 1_000_000.0
                val score = (mbps / 100.0 * 65 + (100.0 - ping.coerceAtMost(200.0)) * 0.25).roundToInt().coerceIn(0, 100)
                runOnUiThread {
                    speedText.text = String.format(Locale.US, "%.2f Mbps", mbps)
                    scoreText.text = "امتیاز کیفیت: $score / ۱۰۰  •  تأخیر تقریبی: ${ping.roundToInt()} ms"
                    gauge.setSpeed(mbps)
                    refreshNetworkLabel()
                }
            } catch (e: Exception) { runOnUiThread { scoreText.text = "سنجش ناموفق: اتصال اینترنت یا دسترسی سرور را بررسی کن."; toast(e.message ?: "خطا در سنجش") } }
        }
    }

    private fun fetchBytes(url: String, limit: Int): Long {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12000; c.readTimeout = 20000; c.setRequestProperty("Cache-Control", "no-cache")
        return try { c.inputStream.use { input -> val buf = ByteArray(65536); var total = 0L; while (total < limit) { val n = input.read(buf, 0, minOf(buf.size, limit - total.toInt())); if (n < 0) break; total += n }; total } } finally { c.disconnect() }
    }

    private fun isWifiConnected(): Boolean = activeHas(NetworkCapabilities.TRANSPORT_WIFI)
    private fun isCellularConnected(): Boolean = activeHas(NetworkCapabilities.TRANSPORT_CELLULAR)
    private fun activeHas(type: Int): Boolean { val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager; return cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(type) == true }

    @Suppress("DEPRECATION")
    private fun scanWifi() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) { requestNeededPermissions(); toast("مجوز مکان را فعال کن و دوباره اسکن بزن."); return }
        wifiList.removeAllViews(); wifiList.addView(label("در حال اسکن…", 13, Color.WHITE, false))
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                try { unregisterReceiver(this) } catch (_: Exception) {}
                wifiList.removeAllViews()
                val results = wifiManager.scanResults.sortedByDescending { it.level }
                if (results.isEmpty()) { wifiList.addView(label("شبکه‌ای دریافت نشد؛ مکان و Wi‑Fi را روشن کن و بعداً دوباره تلاش کن.", 13, Color.WHITE, false)); return }
                results.forEach { r ->
                    val bars = WifiManager.calculateSignalLevel(r.level, 5)
                    val line = "${r.SSID.ifBlank { "شبکه مخفی" }}   •   ${r.level} dBm   •   ${r.frequency} MHz   •   ${r.capabilities.take(35)}"
                    val item = label(line, 12, if (bars >= 3) mint else 0xFFFFC857.toInt(), false)
                    item.setPadding(12, 13, 12, 13); item.background = rounded(panel, 12); val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 7; wifiList.addView(item, lp)
                }
            }
        }
        registerReceiver(receiver, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION))
        val started = wifiManager.startScan()
        if (!started) { try { unregisterReceiver(receiver) } catch (_: Exception) {}; wifiList.removeAllViews(); wifiList.addView(label("اندروید اسکن را محدود کرده است؛ چند ثانیه بعد دوباره تلاش کن.", 13, 0xFFFFC857.toInt(), false)) }
    }

    private fun connectVpn() {
        val raw = vpnConfig.text.toString().trim()
        if (raw.isBlank()) { toast("ابتدا فایل پیکربندی WireGuard را از ارائه‌دهنده سرور دریافت و وارد کن."); return }
        try {
            val config = Config.parse(StringReader(raw))
            val intent = android.net.VpnService.prepare(this)
            if (intent != null) { startActivityForResult(intent, 77); pendingConfig = raw; return }
            activateVpn(config)
        } catch (e: Exception) { toast("فایل پیکربندی معتبر نیست: ${e.message ?: "خطا"}") }
    }
    private var pendingConfig: String? = null
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) { super.onActivityResult(requestCode, resultCode, data); if (requestCode == 77 && resultCode == RESULT_OK) { pendingConfig?.let { raw -> try { activateVpn(Config.parse(StringReader(raw))) } catch (e: Exception) { toast("خطا در پیکربندی VPN") } }; pendingConfig = null } }
    private fun activateVpn(config: Config) { thread { try { backend?.setState(tunnel, Tunnel.State.UP, config); runOnUiThread { vpnUp = true; vpnStatus.text = "● تونل فعال است"; toast("درخواست اتصال WireGuard اجرا شد.") } } catch (e: Exception) { runOnUiThread { toast("اتصال VPN ناموفق: ${e.message ?: "خطا"}") } } } }
    private fun disconnectVpn() { thread { try { backend?.setState(tunnel, Tunnel.State.DOWN, null); runOnUiThread { vpnUp = false; vpnStatus.text = "○ تونل قطع است" } } catch (e: Exception) { runOnUiThread { toast("قطع VPN ناموفق بود") } } } }

    private fun section(s: String) = label(s, 18, mint, true).apply { setPadding(2, 22, 2, 9) }
    private fun label(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD; setPadding(2, 5, 2, 5) }
    private fun edit(hintText: String, multiline: Boolean = false) = EditText(this).apply { hint = hintText; setTextColor(Color.WHITE); setHintTextColor(0xFF7189A3.toInt()); textSize = 13f; setPadding(14, 12, 14, 12); background = rounded(panel, 14); if (multiline) { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; gravity = Gravity.TOP; isSingleLine = false } else { inputType = InputType.TYPE_CLASS_TEXT; isSingleLine = true }; val p = LinearLayout.LayoutParams(-1, if (multiline) 160 else 54); p.topMargin = 7; p.bottomMargin = 7; layoutParams = p }
    private fun button(s: String, action: () -> Unit) = TextView(this).apply { text = s; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(bg); background = rounded(mint, 14); setPadding(12, 15, 12, 15); setOnClickListener { action() }; val p = LinearLayout.LayoutParams(-1, -2); p.setMargins(3, 7, 3, 7); layoutParams = p }
    private fun horizontal() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun weightParams() = LinearLayout.LayoutParams(0, -2, 1f)
    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 12, 14, 12); background = rounded(panel, 16); val p = LinearLayout.LayoutParams(-1, -2); p.topMargin = 9; layoutParams = p }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    class GaugeView(context: android.content.Context) : View(context) {
        private val p = android.graphics.Paint(3)
        private var value = 0.0
        fun setSpeed(v: Double) { value = v; invalidate() }
        override fun onDraw(c: android.graphics.Canvas) { super.onDraw(c); val w = width.toFloat(); val h = height.toFloat(); val cx = w/2; val cy = h*0.82f; val radius = minOf(w*0.39f, h*0.76f); p.style = android.graphics.Paint.Style.STROKE; p.strokeWidth = 19f; p.strokeCap = android.graphics.Paint.Cap.ROUND
            val colors = intArrayOf(Color.rgb(45,205,120), Color.rgb(224,215,55), Color.rgb(255,151,45), Color.rgb(235,65,70)); val rect = android.graphics.RectF(cx-radius, cy-radius, cx+radius, cy+radius)
            var start = 180f; for (i in colors.indices) { p.color = colors[i]; c.drawArc(rect, start, 45f, false, p); start += 48f }
            val frac = (value / 150.0).coerceIn(0.0,1.0); val angle = Math.toRadians(180.0 + 180.0*frac); p.color = Color.WHITE; p.strokeWidth = 5f; c.drawLine(cx,cy,cx+(radius-25)*kotlin.math.cos(angle).toFloat(),cy+(radius-25)*kotlin.math.sin(angle).toFloat(),p); p.style = android.graphics.Paint.Style.FILL; c.drawCircle(cx,cy,9f,p)
            p.textAlign = android.graphics.Paint.Align.CENTER; p.textSize = 12f; p.color = 0xFF91A9C2.toInt(); c.drawText("۰", cx-radius+3, cy+24, p); c.drawText("۷۵", cx, cy-radius+4, p); c.drawText("۱۵۰+ Mbps", cx+radius-28, cy+24, p)
        }
    }
}
